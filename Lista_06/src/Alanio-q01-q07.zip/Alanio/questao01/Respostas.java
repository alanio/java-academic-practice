package questao01;

public class Respostas {
    String letraA = "A classe Ponto3D herda da classe Ponto2D mas nao implementa o construtor da classe Ponto2D";
    String letraB = "Java nao permite heranca multipla diretamente";
    String letraC = "A classe nao deve ser inicializada por um metodo e sim por um construtor";
    String letraD = "No construtor, nao deve haver nenhum codigo antes da utilizacao do construtor da classe pai (super)";
    
    String letraE = "A classe nao herda de nenhuma classe explicitamente, a referencia"
            + " super do construtor da classe pai faz referencia a classe Object, e nao deve ter argumentos";
    
    String letraF = "A classe Ponto2D nao permite herenca por conta do modificador final, nao pode ser herdada em ponto3D";
}
